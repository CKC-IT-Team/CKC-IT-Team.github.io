Double click 'pw.html'. should be apparent from there
universal edition
10.24.24

v2.1.0P1